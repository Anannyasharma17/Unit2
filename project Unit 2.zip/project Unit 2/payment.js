
    function submit(){
    var firstname = document.getElementById("first_name").value;
    var lastname = document.getElementById("last_name").value;
    var mobilenumber = document.getElementById("mobile_number").value;
    // document.querySelector("#hide").style.display = "none";
   
    
        if (firstname == ""){
        document.querySelector("#wrong_first_name").textContent = "Please enter a first name using letters only.";
        }

        if (lastname == ""){
            document.querySelector("#wrong_last_name").textContent = "Please enter a last name using letters only";
        }
        
        if (mobilenumber == "" || mobilenumber.length < 10){
            document.querySelector("#wrong_number").textContent = "Please enter a valid mobile number";
        }
    }


        function check(){
            var four3 = document.getElementById("four_3in").value;
            var four4 = document.getElementById("four_4in").value;
            var four5 = document.getElementById("four_5in").value;
            var four6 = document.getElementById("four_6in").value;
            var four6_2 = document.getElementById("four_6_2in").value;

            if (four3 == ""){
                document.querySelector("#wrong_name").textContent = "Please enter the cardholder's name exactly as it appears on the card.";
            }

            if (four4 == ""){
                document.querySelector("#wrong_carddetails").textContent = "Please enter a valid card number.";
            }

            if (four5 == ""){
                document.querySelector("#wrong_expirydate").textContent = "Please choose a valid month and year.";
            }

            if (four6 == ""){
                document.querySelector("#wrong_securitycode").textContent = "Please enter a valid card security code";
            }
            if (four6_2== ""){
                document.querySelector("#wrong_zipcode").textContent = "Please enter a ZIP code";
            }
        }

        var count = 0;
        document.querySelector("#sutta1").style.display = "none";
        document.querySelector("#sutta2").style.display = "none";
        document.querySelector("#hide1").style.display = "none";
        document.querySelector("#hide2").style.display = "none";
        
        function show1(){
           if (count == 0){
              var z = document.querySelector("#sutta1")
              z.style.display = "none";
              document.querySelector("#sutta2").style.display = "none";
             return  count++;
           } 

           
           else{
           var z = document.querySelector("#sutta1")
            z.style.display = "block";
            document.querySelector("#sutta2").style.display = "block";
            return count--;
           }
        }

        var count2 = 0;
       function show2(){
           if (count2 == 0){
              var y = document.querySelector("#hide1")
              y.style.display = "none";
              document.querySelector("#hide2").style.display = "none";
             return  count2++;
           } 
           else{
            var y = document.querySelector("#hide1")
            y.style.display = "block";
            document.querySelector("#hide2").style.display = "block";
            return count2--;
           }
        }


        var card_data = [
            {card_num: "12345", exp_y: "34", exp_m: "10",  securitycode: "123", name: "Chandra Shekhar"}
        ]
    
        // localStorage.setItem("cardData", JSON.stringify(card_data));
    
    
        document.querySelector("form").addEventListener("submit", wrong);
    
        function wrong(event) {
    
            event.preventDefault();
            
            document.querySelector("#wrong_card").textContent = "";
            document.querySelector("#wrong_exp_date").textContent = "";
            document.querySelector("#wrong_cvv").textContent = "";
            document.querySelector("#wrong_name").textContent = "";
            document.querySelector("#wrong_check").textContent = "";
    
            var checkbox = document.querySelector("input[type=checkbox]");
    
            if (checkbox.checked) {
                // console.log("Checkbox is checked..");
                
                var card = document.querySelector("#newCard").value;
    
                if(card == "") {
                    document.querySelector("#wrong_card").textContent = "Card Number is required";
                }
    
                var expiry = document.querySelector("#expiry").value;
    
                if(expiry == "") {
                    document.querySelector("#wrong_exp_date").textContent = "Enter valid expiry date";
                }
    
                var cvv = document.querySelector("#cvv").value;
    
                if(cvv == "") {
                    document.querySelector("#wrong_cvv").textContent = "Enter valid cvv number";
                }
    
                var name = document.querySelector("#name").value;
    
                if(name == "") {
                    document.querySelector("#wrong_name").textContent = "Please enter valid name as per on card";
                }      
                
                if(card != "" && expiry != "" && cvv != "" && name != "") {
    
                    card_data.map(function (items) {
                        if(card == items.card_num && expiry == items.exp && cvv == items.cvv && name == items.name) {
                            alert("Redirecting you to payment gateway");
    
                        }
                        else {
                            document.querySelector("#wrong_check").textContent = "Sorry!! wrong credentials";
                        }
                    });               
                }
            } 
            else {
                // console.log("Checkbox is not checked..");
                alert("please tick the checkbox");
                document.querySelector("#wrong_check").textContent = "please tick the checkbox";
            }
        }

        




        

